package com.prajval.impl;

import com.prajval.responce.AutomationResponse;
import com.prajval.service.extractor.ExtractorService;
import com.prajval.service.locators.LocatorResolverService;
import io.appium.java_client.AppiumDriver;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.constraints.NotNull;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Service
public class ILocatorResolverService extends ExtractorService implements LocatorResolverService {

    @Override
    public AutomationResponse captureLocatorsFromScreens(
            AppiumDriver driver,
            Map<String, List<String>> screenLocators,
            HttpServletRequest request,
            HttpServletResponse response
    ) {
        String pageSource = driver.getPageSource();
        List<String> locators = extractLocatorsFromSource(pageSource, request, response);

        // Save locators for the screen
        String screenName = driver.getCurrentUrl(); // For apps, this may be package name + activity
        screenLocators.put(screenName, locators);

        return AutomationResponse.builder()
                .data(List.of(screenLocators))
                .build();
    }

    @Override
    protected List<String> extractLocatorsFromSource(
            @NotNull String source,
            HttpServletRequest request,
            HttpServletResponse response
    ) {
        List<String> locators = new ArrayList<>();
        // Use an XML parser to get all elements and their potential locators (e.g., ID, XPath, etc.)
        // For now, let's assume we extract XPath and resource-id
        Document document = Jsoup.parse(source);
        Elements elements = document.select("*");

        for (Element element : elements) {
            String resourceId = element.attr("resource-id");
            if (!resourceId.isEmpty()) {
                locators.add("ID: " + resourceId);
            } else {
                String xpath = element.cssSelector();
                locators.add("XPath: " + xpath);
            }
        }
        System.out.println(Arrays.toString(locators.toArray()));
        return locators;
    }
}
