package com.prajval.service;

import com.prajval.responce.AutomationResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.constraints.NotNull;

public interface AnalyserService {

    AutomationResponse analyzeBuild(
            @NotNull String filePath,
            @NotNull String platform,
            HttpServletRequest request,
            HttpServletResponse response
    );
}
