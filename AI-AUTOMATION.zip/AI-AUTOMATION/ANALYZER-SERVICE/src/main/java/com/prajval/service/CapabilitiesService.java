package com.prajval.service;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.constraints.NotNull;
import org.openqa.selenium.remote.DesiredCapabilities;

public interface CapabilitiesService {

    DesiredCapabilities fetchCapabilities(
            @NotNull String platForm,
            @NotNull String buildPath,
            HttpServletRequest request,
            HttpServletResponse response
    );
}
