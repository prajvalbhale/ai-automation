package com.prajval.service;

public interface PlatformService {
}
