package com.prajval.dto;

import lombok.Data;

@Data
public class AnalyzerDto {
    private String filePath;
    private String platform;
}
