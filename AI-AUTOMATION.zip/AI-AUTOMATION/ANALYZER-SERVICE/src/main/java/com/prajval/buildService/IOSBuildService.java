package com.prajval.buildService;

import com.prajval.responce.AutomationResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.constraints.NotNull;

public interface IOSBuildService {

    AutomationResponse analyzeIOSBuild(
            @NotNull String buildPath,
            HttpServletRequest request,
            HttpServletResponse response
    );
}
