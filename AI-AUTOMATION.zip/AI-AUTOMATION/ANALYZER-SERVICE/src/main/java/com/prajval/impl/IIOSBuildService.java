package com.prajval.impl;

import com.prajval.buildService.IOSBuildService;
import com.prajval.responce.AutomationResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.constraints.NotNull;
import org.springframework.stereotype.Service;

@Service
public class IIOSBuildService implements IOSBuildService {

    @Override
    public AutomationResponse analyzeIOSBuild(
            @NotNull String buildPath,
            HttpServletRequest request,
            HttpServletResponse response
    ) {
        return null;
    }
}
