package com.prajval.service.locators;

import com.prajval.responce.AutomationResponse;
import io.appium.java_client.AppiumDriver;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.util.List;
import java.util.Map;

public interface LocatorResolverService {

    AutomationResponse captureLocatorsFromScreens(
            AppiumDriver driver,
            Map<String, List<String>> screenLocators,
            HttpServletRequest request,
            HttpServletResponse response
    );
}
