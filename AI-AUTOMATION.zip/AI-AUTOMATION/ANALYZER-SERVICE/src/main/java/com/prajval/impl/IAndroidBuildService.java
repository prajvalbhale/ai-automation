package com.prajval.impl;

import com.prajval.buildService.AndroidBuildService;
import com.prajval.responce.AutomationResponse;
import com.prajval.service.CapabilitiesService;
import com.prajval.service.locators.LocatorResolverService;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.constraints.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class IAndroidBuildService implements AndroidBuildService {

    private final LocatorResolverService locatorResolverService;

    private final CapabilitiesService capabilitiesService;

    @Autowired
    public IAndroidBuildService(
            LocatorResolverService locatorResolverService,
            CapabilitiesService capabilitiesService
    ) {
        this.locatorResolverService = locatorResolverService;
        this.capabilitiesService = capabilitiesService;
    }

    @Override
    public AutomationResponse analyzeAndroidBuild(
            @NotNull String buildPath,
            HttpServletRequest request,
            HttpServletResponse response
    ) {
        Map<String, List<String>> screenLocators = new HashMap<>();
        AutomationResponse automationResponse = AutomationResponse.builder().build();

        try {
            AppiumDriver driver = new AndroidDriver(
                    new URL("http://localhost:4723/wd/hub"),
                    capabilitiesService.fetchCapabilities(
                            "android",
                            buildPath,
                            request,
                            response
                    )
            );

            automationResponse = locatorResolverService.captureLocatorsFromScreens(
                    driver,
                    screenLocators,
                    request,
                    response);

            driver.quit();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return AutomationResponse.builder()
                .data(
                        List.of(
                                automationResponse,
                                screenLocators
                        ))
                .build();
    }
}
