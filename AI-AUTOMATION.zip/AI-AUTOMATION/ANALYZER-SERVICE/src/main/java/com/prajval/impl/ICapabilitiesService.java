package com.prajval.impl;

import com.prajval.service.CapabilitiesService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.constraints.NotNull;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
public class ICapabilitiesService implements CapabilitiesService {

    @Override
    public DesiredCapabilities fetchCapabilities(
            @NotNull String platForm,
            @NotNull String buildPath,
            HttpServletRequest request,
            HttpServletResponse response
    ) {
        if (Objects.deepEquals(platForm.toUpperCase(), "ANDROID")) {
            DesiredCapabilities capabilities = new DesiredCapabilities();
            capabilities.setCapability("app", buildPath);
            capabilities.setCapability("platformName", "Android");
            capabilities.setCapability("automationName", "UiAutomator2");
            return capabilities;
        } else {
            DesiredCapabilities capabilities = new DesiredCapabilities();
            capabilities.setCapability("app", buildPath);
            capabilities.setCapability("platformName", "Android");
            capabilities.setCapability("automationName", "UiAutomator2");
            return capabilities;
        }
    }
}
