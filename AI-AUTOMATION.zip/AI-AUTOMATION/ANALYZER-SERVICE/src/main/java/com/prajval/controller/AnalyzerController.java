package com.prajval.controller;

import com.prajval.dto.AnalyzerDto;
import com.prajval.responce.AutomationResponse;
import com.prajval.service.AnalyserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.constraints.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/api/v1/analyzer")
public class AnalyzerController {

    private final AnalyserService analyserService;

    @Autowired
    public AnalyzerController(
            AnalyserService analyserService
    ) {
        this.analyserService = analyserService;
    }

    @PostMapping
    public ResponseEntity<AutomationResponse> processBuildAnalysis(
            @RequestBody @NotNull AnalyzerDto analyzerDto,
            HttpServletRequest request,
            HttpServletResponse response
    ) {
        AutomationResponse automationResponse = analyserService.analyzeBuild(
                analyzerDto.getFilePath(),
                analyzerDto.getPlatform(),
                request,
                response
        );
        if (Objects.deepEquals(automationResponse.getData(), List.of()))
            return new ResponseEntity<>(automationResponse, HttpStatus.BAD_REQUEST);
        else
            return new ResponseEntity<>(automationResponse, HttpStatus.OK);
    }
}
