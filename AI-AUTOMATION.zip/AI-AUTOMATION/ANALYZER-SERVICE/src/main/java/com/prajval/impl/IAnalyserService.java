package com.prajval.impl;

import com.prajval.buildService.AndroidBuildService;
import com.prajval.buildService.IOSBuildService;
import com.prajval.models.Message;
import com.prajval.responce.AutomationResponse;
import com.prajval.service.AnalyserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.constraints.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IAnalyserService implements AnalyserService {

    private final AndroidBuildService androidBuildService;

    private final IOSBuildService iosBuildService;

    @Autowired
    public IAnalyserService(
            AndroidBuildService androidBuildService,
            IOSBuildService iosBuildService
    ) {
        this.androidBuildService = androidBuildService;
        this.iosBuildService = iosBuildService;
    }

    @Override
    public AutomationResponse analyzeBuild(
            @NotNull String filePath,
            @NotNull String platform,
            HttpServletRequest request,
            HttpServletResponse response
    ) {
        return switch (platform.toUpperCase()) {
            case "ANDROID" -> androidBuildService.analyzeAndroidBuild(filePath, request, response);
            case "IOS" -> iosBuildService.analyzeIOSBuild(filePath, request, response);
            default -> AutomationResponse.builder()
                    .message(
                            Message.builder()
                                    .code(101)
                                    .message("")
                                    .build())
                    .data(List.of())
                    .build();
        };
    }
}
