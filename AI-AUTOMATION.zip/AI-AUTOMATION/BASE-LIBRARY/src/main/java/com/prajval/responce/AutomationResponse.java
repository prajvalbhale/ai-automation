package com.prajval.responce;

import com.prajval.models.Message;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class AutomationResponse {
    private Message message;
    private List<?> data;
}
