package com.prajval.entity;

public class BaseEntity {
}
