package com.prajval.enums;

public enum ErrorMessage {
}
