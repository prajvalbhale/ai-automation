package com.prajval.dto;

public class BaseDto {
}
