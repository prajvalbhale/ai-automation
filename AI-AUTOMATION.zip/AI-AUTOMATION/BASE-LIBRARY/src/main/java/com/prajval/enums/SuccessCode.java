package com.prajval.enums;

public enum SuccessCode {
}
